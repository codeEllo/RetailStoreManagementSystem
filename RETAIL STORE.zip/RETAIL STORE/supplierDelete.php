<html>
<head>
</head>
	<style>
	body{
  			background: url("retailshop.jpg") no-repeat fixed center;
			height: 100vh;
			background-size: cover;
    		background-position: center;
		}
	</style>
<body>
<?php
$suID = $_GET['Supp_ID'];
$dbc = mysqli_connect ("localhost","root","","retail store system"); if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql = "select * from item where Supp_ID = '$suID'";
$results = mysqli_query($dbc, $sql);
$row = mysqli_fetch_assoc($results);
?>
<form action="supplierDeleteProcess.php?Supp_ID=<?php echo $suID;?>"method="post">
<h1 align="center">Delete Supplier Record</h1>
<table align="center" border="1">
<h3>
<tr>
<h3><td>Supplier ID</td>
<td><input type="text" name="Supp_ID" value='<?=$row['Supp_ID'];?>' disabled></td>
</h3>
</tr>
<tr>
<td>Company Name</td>
<td><input type="text" name="Supp_CompnyName" value='<?=$row['Supp_CompnyName'];?>'></td>
</tr>
<tr>
<td>Supplier State</td>
<td><input type="text" name="Supp_State" value='<?=$row['Supp_State'];?>'></td>
</tr>
<tr>
<td>Phone Number</td>
<td><input type="text" name="Supp_PhNum" value='<?=$row['Supp_PhNum'];?>'></td>
</tr>
	<tr>
<td>Invoice Number</td>
<td><input type="text" name="Supp_IvNum" value='<?=$row['Supp_IvNum'];?>'></td>
</tr>
	<tr>
<td>Staff ID</td>
<td><input type="text" name="STAFF_ID" value='<?=$row['STAFF_ID'];?>'></td>
</tr>
<td colspan="2"><center><input type="submit" value="Delete" onClick="return confirm('Are you sure?')"></td>
</h3>
</table>
</form>
</body>
</html>
