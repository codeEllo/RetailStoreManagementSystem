<?php
$iCode = $_GET['IT_CODE'];
$iName = $_POST['IT_NAME'];
$iManu = $_POST['IT_MANUFACTURED'];
$iExp = $_POST['IT_EXPIREDATE'];
$iQuan = $_POST['IT_QUANTITY'];
$iRDate = $_POST['IT_RDATE'];
$suID = $_POST['Supp_ID'];
$sID = $_POST['STAFF_ID'];

$dbc = mysqli_connect ("localhost", "root","","retail store system"); if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql = "update `item` set
`IT_CODE`='$iCode',`IT_NAME`='$iName',`IT_MANUFACTURED`='$iManu',`IT_EXPIREDATE`='$iExp',`IT_QUANTITY`='$iQuan',`IT_RDATE`='$iRDate',`Supp_ID`='$suID',`STAFF_ID`='$sID' where `IT_CODE`='$iCode'";
$result = mysqli_query($dbc, $sql);

if($result)
{
mysqli_commit($dbc);
Print '<script>alert("New Item Record is successfully updated.");</script>';
Print '<script>window.location.assign("itemList.php");</script>';
}
else
{
mysqli_rollback($dbc);
Print '<script>alert("Item Record is failed to update.");</script>';
Print '<script>window.location.assign("itemList.php");</script>';
}
?>
