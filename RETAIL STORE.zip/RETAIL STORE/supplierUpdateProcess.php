<?php
$suID = $_GET['Supp_ID'];
$suCname = $_POST['Supp_CompnyName'];
$suState = $_POST['Supp_State'];
$suPhnum = $_POST['Supp_PhNum'];
$suIvNum = $_POST['Supp_IvNum'];
$suStaff = $_POST['STAFF_ID'];

$dbc = mysqli_connect ("localhost", "root","","retail store system"); if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql = "update `supplier` set
`Supp_ID`='$suID',`Supp_CompnyName`='$suCname',`Supp_State`='$suState',`Supp_PhNum`='$suPhnum',`Supp_IvNum`='$suIvNum',`STAFF_ID`='$suStaff' where
`Supp_ID`='$suID'";
$result = mysqli_query($dbc, $sql);

if($result)
{
mysqli_commit($dbc);
Print '<script>alert("New Supplier Record is successfully updated.");</script>';
Print '<script>window.location.assign("supplierList.php");</script>';
}
else
{
mysqli_rollback($dbc);
Print '<script>alert("Supplier Record is failed to update.");</script>';
Print '<script>window.location.assign("supplierList.php");</script>';
}

?>
