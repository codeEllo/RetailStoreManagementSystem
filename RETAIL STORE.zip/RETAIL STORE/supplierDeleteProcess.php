<?php
$suID = $_GET['Supp_ID'];
$dbc = mysqli_connect ("localhost", "root", "", "retail store system"); if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql = "DELETE FROM supplier where Supp_ID='$suID'";
$result = mysqli_query($dbc, $sql); if($result)
{
mysqli_commit($dbc);
Print '<script>alert("Supplier Record Successfuly Deleted.");</script>';
Print '<script>window.location.assign("supplierList.php");</script>';
}
else
{
mysqli_rollback($dbc);
Print '<script>alert("Supplier Record is failed to be Deleted.");</script>'; 
Print '<script>window.location.assign("supplierList.php");</script>';
}
?>
