<html>
<head>
	<style>
		body{
  			background: url("retailshop.jpg") no-repeat fixed center;
			height: 100vh;
			background-size: cover;
    		background-position: center;
		}
		
	ul a {
 			background-color: #767474;
  			color: white;
 		    padding: 15px 32px;
  			text-align: center;
		  	text-decoration: none;
		  	display: inline-block;
		  	font-size: 16px;
		  	margin: 4px 2px;
		  	position: relative;
			left: 24%;
			transition: 0.3s ease;
		}
	</style>
	<link href="style.css" rel="stylesheet" type="text/css">
<title>ITEM LIST</title>
</head>

<body class="style">
	<ul>
				<a href="">HOMEPAGE</a>
	  			<a href="">STAFF</a>
				<a href="supplierList.php">SUPPLIER</a>
				<a href="itemList.php">ITEM</a>
				<a href="">SALES</a>
	</ul>
<form class="background">
<h2 align="center"><font color="#000000">ITEM LIST</font></h2>
<table align="center" border="1">
<tr>
<th><font color="#000000">ITEM CODE</font></th>
<th><font color="#000000">NAME</font></th>
<th><font color="#000000">MANUFACTURED</font></th>
<th><font color="#000000">QUANTITY</font></th>
<th><font color="#000000">EXPIRED DATE</font></th>
<th><font color="#000000">RECIEVED DATE</font></th>
<th><font color="#000000">SUPPLIER ID</font></th>
<th><font color="#000000">STAFF ID</font></th>
<th colspan="2"><font color="#000000">Action</font></th>
</tr>
<?php
$dbc = mysqli_connect ("localhost","root","","retail store system"); if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
$sql = "select * from item";
$result = mysqli_query($dbc, $sql); while($row = mysqli_fetch_assoc($result)) { Print '<tr>
<td><font color="#000000">'.$row['IT_CODE'].'</font></td>
<td><font color="#000000">'.$row['IT_NAME'].'</font></td>
<td><font color="#000000">'.$row['IT_MANUFACTURED'].'</font></td>
<td><font color="#000000">'.$row['IT_QUANTITY'].'</font></td>
<td><font color="#000000">'.$row['IT_EXPIREDATE'].'</font></td>
<td><font color="#000000">'.$row['IT_RDATE'].'</font></td>
<td><font color="#000000">'.$row['Supp_ID'].'</font></td>
<td><font color="#000000">'.$row['STAFF_ID'].'</font></td>
<td>
<a href="itemUpdate.php?IT_CODE='.$row['IT_CODE'].' & " class="btn btn-warning" role="button">Update</a>
</td>
<td>
<a href="itemDelete.php?IT_CODE='.$row['IT_CODE'].'" class="btn btn-danger" role="button"><font color="#C70D11">Delete</font></a>
</td>
</tr>';
}
?>
</table>
</form>
</body>
</html>
