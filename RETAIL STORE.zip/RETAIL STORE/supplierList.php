<html>
<head>
	<style>
		body{
  			background: url("retailshop.jpg") no-repeat fixed center;
			height: 100vh;
			background-size: cover;
    		background-position: center;
		}
		
	ul a {
 			background-color: #767474;
  			color: white;
 		    padding: 15px 32px;
  			text-align: center;
		  	text-decoration: none;
		  	display: inline-block;
		  	font-size: 16px;
		  	margin: 4px 2px;
		  	position: relative;
			left: 24%;
			transition: 0.3s ease;
		}
	</style>
	<link href="style.css" rel="stylesheet" type="text/css">
<title>SUPPLIER LIST</title>
</head>

<body class="style">
	<ul>
				<a href="">HOMEPAGE</a>
	  			<a href="">STAFF</a>
				<a href="supplierList.php">SUPPLIER</a>
				<a href="itemList.php">ITEM</a>
				<a href="">SALES</a>
	</ul>
<form class="background">
<h2 align="center"><font color="#000000">SUPPLIER LIST</font></h2>
<table align="center" border="1">
<tr>
<th><font color="#000000">Supplier ID</font></th>
<th><font color="#000000">Company Name</font></th>
<th><font color="#000000">Supplier State</font></th>
<th><font color="#000000">Phone Number</font></th>
<th><font color="#000000">Invoice Number</font></th>
<th><font color="#000000">Staff ID</font></th>
<th colspan="2"><font color="#000000">Action</font></th>
</tr>
<?php
$dbc = mysqli_connect ("localhost","root","","retail store system"); if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
$sql = "select * from supplier";
$result = mysqli_query($dbc, $sql); while($row = mysqli_fetch_assoc($result)) { Print '<tr>
<td><font color="#000000">'.$row['Supp_ID'].'</font></td>
<td><font color="#000000">'.$row['Supp_CompnyName'].'</font></td>
<td><font color="#000000">'.$row['Supp_State'].'</font></td>
<td><font color="#000000">'.$row['Supp_PhNum'].'</font></td>
<td><font color="#000000">'.$row['Supp_IvNum'].'</font></td>
<td><font color="#000000">'.$row['STAFF_ID'].'</font></td>
<td>
<a href="supplierUpdate.php?Supp_ID='.$row['Supp_ID'].' & " class="btn btn-warning" role="button">Update</a>
</td>
<td>
<a href="supplierDelete.php?Supp_ID='.$row['Supp_ID'].'" class="btn btn-danger" role="button"><font color="#C70D11">Delete</font></a>
</td>
</tr>';
}
?>
</table>
</form>
</body>
</html>
