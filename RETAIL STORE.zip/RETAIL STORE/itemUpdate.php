<html>
<head>
</head>
	<style>
	body{
  			background: url("retailshop.jpg") no-repeat fixed center;
			height: 100vh;
			background-size: cover;
    		background-position: center;
		}
	</style>
<body>
<?php
$iCode = $_GET['IT_CODE'];
$dbc = mysqli_connect ("localhost","root","","retail store system"); if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: ".mysqli_connect_error();
}
$sql = "select * from item where IT_CODE = '$iCode'";
$result = mysqli_query($dbc,$sql); if (false === $result)
{
echo mysqli_error();
}
$row = mysqli_fetch_assoc($result)
?>
<form action="itemUpdateProcess.php?Supp_ID=<?php echo $suID;?>" method="post">
<h2 align="center">Update Item Record</h2>
<table align="center" border="1">
<h3>
<tr>
<td>ITEM CODE</td>
<td><input type="text" name="IT_CODE" value='<?=$row['ITEM CODE'];?>' disabled></td>
</tr>
<tr>
<td>ITEM NAME</td>
<td><input type="text" name="IT_NAME" value='<?=$row['IT_NAME'];?>'></td>
</tr>
<tr>
<td>ITEM MANUFACTURED</td>
<td><input type="text" name="IT_MANUFACTURED" value='<?=$row['IT_MANUFACTURED'];?>'></td>
</tr>
<tr>
<td>ITEM QUANTITY</td>
<td><input type="text" name="IT_QUANTITY" value='<?=$row['IT_QUANTITY'];?>'></td>
</tr>
<tr>
<td>ITEM EXPIRED DATE</td>
<td><input type="text" name="IT_EXPIREDATE" value='<?=$row['IT_EXPIREDATE'];?>'></td>
</tr>
<tr>
<td>ITEM RECIEVED DATE</td>
<td><input type="text" name="IT_RDATE" value='<?=$row['IT_RDATE'];?>'></td>
</tr>
<tr>
<td>SUPPLIER ID</td>
<td><input type="text" name="Supp_ID" value='<?=$row['Supp_ID'];?>'></td>
</tr>
<tr>
<td>STAFF ID</td>
<td><input type="text" name="STAFF_ID" value='<?=$row['STAFF_ID'];?>'></td>
</tr>
<tr>
<td colspan="2"><center><input type="submit" value="Update" onClick="return confirm('Are you sure?')"></center></td>
</tr>
	</h3>
</table>
</form>
</body>
</html>
